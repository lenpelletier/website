/* Name: _______________________
 * 
 */
import java.util.Scanner;

public class Questions {
    
    Scanner input = new Scanner(System.in);
    
    public void Exercise1() {
        //write your answer in this comment!
        //
    }

    public void Exercise2() {
        //write your answer in this comment!
        //
    }
    
    public void Exercise3() {
        
    }
    
    public void Exercise4() {
        
    }
    
    public void Exercise5() {
        
    }
    
    public void Exercise6() {
        
    }
    
    public void Exercise7() {
        
    }
}