/*
 * File: MyKarelProgram.java
 * --------------------------------
 *
 * MyKarelProgram walks to the beeper, picks it up, and deposits
 * it at the top of the step.
 */

import kareltherobot.*;

public class MyKarelProgram extends Karel {

    // Constructor. Creates a MyKarelProgram robot
    public MyKarelProgram() {
        super(1, 1, 0, "worlds/MyFirstKarelWorld.kwld");
    }

    // The run method automatically starts when you create 
    // a new MyKarelProgram robot
    public void run() {
        move();
        pickBeeper();
        turnLeft();
        move();
        turnRight();
        move();
        putBeeper();
        move();
    }

    //This is a method that we defined
    private void turnRight() {
        turnLeft();
        turnLeft();
        turnLeft();
    }
}