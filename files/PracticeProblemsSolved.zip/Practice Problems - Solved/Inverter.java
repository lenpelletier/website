/*
 * File: Inverter.java
 * --------------------------------
 *
 * Inverter walks along the bottom of the screen.  If it encounters a
 * beeper, it picks it up.  If it does not, it places one down.
 */

import kareltherobot.*;

public class Inverter extends SuperKarel {

    // Constructor. You should not change anything in this method for the assignment
    public Inverter() {
        super(1, 1, 99, "worlds/inverter2.kwld");
    }

    public void run() {
        while (frontIsClear()) {
            invertBeeper();
            move();
        }
        invertBeeper();
    }
    
    private void invertBeeper() {
        if (beepersPresent()) {
            pickBeeper();
        }
        else {
            putBeeper();
        }
    }

}

