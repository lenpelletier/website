import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

class FileIOExample {
    
    public static void main (String[] args) {
        System.out.println("Open files...");
        File source = new File("cthulhu.txt");
        File dest   = new File("cthulhu2.txt");
        int count   = 0;
        
        try {
            System.out.println("read/write");
            Scanner input = new Scanner(source);
            PrintWriter output = new PrintWriter(dest);
            
            while (input.hasNext()) {
                String line = input.nextLine();
                output.println(line);
                System.out.println(line);
                count++;
            }
            output.close();
        }
        
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println("Done!  Processed " + count + " lines.");
    }

}