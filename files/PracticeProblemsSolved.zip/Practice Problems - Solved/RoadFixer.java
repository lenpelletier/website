/*
 * File: RoadFixer.java
 * --------------------------------
 *
 * RoadFixer walks along the bottom of the screen, filling potholes
 * with beepers every time it encounters them.
 */

import kareltherobot.*;

public class RoadFixer extends SuperKarel {

    // Constructor. You should not change anything in this method for the assignment
    public RoadFixer() {
        super(2, 1, 99, "worlds/roadfixer1.kwld");
    }

    public void run() {
        while (frontIsClear()) {
            checkForHole();
            move();
        }
        checkForHole();
    }

    private void checkForHole() {
        if (rightIsClear()) {
            fillHole();
        }
    }

    private void fillHole() {
        goInHole();
        fixHole();
        leaveHole();
    }

    private void goInHole() {
        turnRight();
        move();
    }

    private void fixHole() {
        putBeeper();
    }

    private void leaveHole() {
        turnAround();
        move();
        turnRight();
    }
}

