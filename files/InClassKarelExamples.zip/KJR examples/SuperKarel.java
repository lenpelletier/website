/*
 * File: SuperKarel.java
 * --------------------------------
 */

import kareltherobot.*; 

public class SuperKarel extends Robot implements Directions {

    //Constructor
    public SuperKarel (int street, int avenue, int beepers, String worldFile) {
        super(street, avenue, East, beepers);
        World.readWorld(worldFile);
        World.setVisible(true);
        World.setDelay(20);
        World.showSpeedControl(true);
        World.setupThread(this);
    }
    
    public void turnRight() {
        int oldDelay = World.delay();
        World.setDelay(0);
        turnLeft();
        turnLeft();
        World.setDelay(oldDelay);
        turnLeft();       
    }
    
    public void turnAround() {
        turnLeft();
        turnLeft();
    }
    
    // Methods that test conditions
    
    public boolean frontIsBlocked() {
        return !frontIsClear();
    }
    
    public boolean leftIsClear() {
        int oldDelay = World.delay();
        World.setDelay(0);
        turnLeft();
        boolean isClear = frontIsClear();
        World.setDelay(oldDelay);
        turnRight();
        return isClear;
    }
    
    public boolean leftIsBlocked() {
        return !leftIsClear();
    }
    
    public boolean rightIsClear() {
        int oldDelay = World.delay();
        World.setDelay(0);
        turnRight();
        boolean isClear = frontIsClear();
        World.setDelay(oldDelay);
        turnLeft();
        return isClear;
    }
    
    public boolean rightIsBlocked() {
        return !rightIsClear();
    }
    
    public boolean beepersPresent() {
        return nextToABeeper();
    }
    
    public boolean noBeepersPresent() {
        return !nextToABeeper();
    }
    
}

