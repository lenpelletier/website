/*
 * File: Hurdler.java
 * --------------------------------
 *
 * Hurdler walks along the bottom of the screen, jumping hurdles
 * every time he encounters them.
 */

import kareltherobot.*;

public class BadCode extends SuperKarel {

    // Constructor. You should not change anything in this method for the assignment
    public BadCode() {
        super(1, 1, 0, "worlds/badCodeWorld.kwld");
    }

    public void run() {
        move();
        turnLeft();
        move();
        move();
        turnRight();
        move();
        turnRight();
        move();
        move();
        turnLeft();
        move();
        turnLeft();
        move();
        move();
        turnRight();
        move();
        turnRight();
        move();
        move();
        turnLeft();
        move();
        move();
        turnLeft();
        move();
        move();
        turnRight();
        move();
        turnRight();
        move();
        move();
        turnLeft();
        move();
        move();
        turnLeft();
        move();
        move();
        turnRight();
        move();
        turnRight();
        move();
        move();
        turnLeft();
        move();
        move();
        move();
    }
}

