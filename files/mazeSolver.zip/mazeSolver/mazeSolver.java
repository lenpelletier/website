/*
 * File: mazeSolver.java
 * --------------------------------
 *
 * mazeSolver should be able to solve any maze.
 * It knows it is at the end of the maze when it
 * encounters a beeper.
 */

import kareltherobot.*;

public class mazeSolver extends SuperKarel {

    // Constructor. You should not change anything in this method for the assignment
    public mazeSolver() {
        super(1, 1, 99, "worlds/maze1.kwld");
    }

    public void run() {
        //your solution goes here!
    }
}

