import kareltherobot.*;

public class Test extends UrRobot implements Directions
{
   
    // Constructor. You should not change anything in this method for the assignment
    public Test() {
        super(1, 1, East, 0);
        World.readWorld("worlds/gg.kwld");
        World.setVisible(true);
        World.setDelay(20);
        World.showSpeedControl(true);
        World.setupThread(this);
    }

    public void run() {
        for (int i = 0; i < 20; i++) {
            turnLeft();
        }
    }
}
