/*
 * File: BeeperCollector.java
 * --------------------------------
 *
 * BeeperCollector collects towers of beepers and stacks all of the
 * beepers it collects at the far side of the world.  It then returns
 * to the beginning of the world.
 */

import kareltherobot.*;

public class BeeperCollector extends SuperKarel {

    // Constructor. You should not change anything in this method for the assignment
    public BeeperCollector() {
        super(1, 1, 0, "worlds/beepercollector1.kwld");
    }

    public void run() {
      collectAllBeepers();
      dropAllBeepers();
      returnHome();
    }
    
    private void collectAllBeepers() {
        while (frontIsClear()) {
            collectTower();
            move();
        }
        collectTower();  //gets the last tower
    }
    
    private void collectTower() {
        turnLeft();
        while (beepersPresent()) {
            pickBeeper();
            move();
        }
        returnHome();
        
    }
    
    private void dropAllBeepers() {
        while (beepersInBag()) {
            putBeeper();
        }
    }
    
    private void returnHome() {
        turnAround();
        while(frontIsClear()) {
            move();
        }
        turnLeft();
    }
}

