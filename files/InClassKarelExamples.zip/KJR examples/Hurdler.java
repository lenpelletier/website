/*
 * File: Hurdler.java
 * --------------------------------
 *
 * Hurdler walks along the bottom of the screen, jumping hurdles
 * every time he encounters them.
 */

import kareltherobot.*;

public class Hurdler extends SuperKarel {

    // Constructor. You should not change anything in this method for the assignment
    public Hurdler() {
        super(1, 1, 0, "worlds/hurdler.kwld");
    }

    public void run() {
        for (int i = 0; i < 4; i++) {
            move();
            jumpHurdle();
        }
        move();
    }

    // precondition: Karel hits the hurdle facing east
    // postcondtion: Karel leaves the hurlde facing east
    private void jumpHurdle() {
        turnLeft();
        ascendHurdle();
        crossHurdle();
        descendHurdle();
        turnLeft();
    }
    
    private void ascendHurdle() {
        move();
        move();
    }
    
    private void crossHurdle() {
        turnRight();
        move();
        turnRight();
    }
    
    private void descendHurdle() {
        move();
        move();
    }
    
}

