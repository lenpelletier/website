/*
 * File: RoadFixer.java
 * --------------------------------
 *
 * RoadFixer walks along the bottom of the screen, filling potholes
 * with beepers every time it encounters them.
 */

import kareltherobot.*;

public class RoadFixer extends SuperKarel {

    // Constructor. You should not change anything in this method for the assignment
    // except to change the map.
    public RoadFixer() {
        super(2, 1, 99, "worlds/roadfixer1.kwld");
    }

    public void run() {
        //You should begin your solution here
    }
}

