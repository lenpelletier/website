// Pelletier
import java.util.List;
import java.util.ArrayList;

public class ListAssignment {
    //Question 4
    public void question4() {
        //Answer in a comment here!
    }

    //Question 5
    public static ArrayList<String> question5(ArrayList<String> lst) {
        return new ArrayList<String>();
    }

    //Question 6
    public static void question6(ArrayList<Integer> lst) {

    }

    //Question 7
    public static void filter(ArrayList<Integer> list1, ArrayList<Integer> list2) {

    }

    //Question 8
    public static void removeConsequtiveDuplicates(ArrayList<String> lst) {

    }

    public static void main(String[] args) {
        ArrayList<String> test5 = new ArrayList<String>();
        test5.add("Steve");test5.add("Ryan");test5.add("Hector");

        System.out.println("Question 5 Test:");
        System.out.println(test5 + " --> " + question5(test5));

        ArrayList<Integer> test6a = new ArrayList<Integer>();
        test6a.add(1);test6a.add(2);test6a.add(4);test6a.add(-1);

        ArrayList<Integer> test6b = new ArrayList<Integer>();
        test6b.add(-1);test6b.add(2);test6b.add(0);test6b.add(9);

        System.out.println("");

        System.out.println("Question 6 Tests:");
        System.out.print(test6a + " --> ");
        question6(test6a);
        System.out.println(test6a);

        System.out.print(test6b + " --> ");
        question6(test6b);
        System.out.println(test6b);

        System.out.println("");

        ArrayList<Integer> test7a = new ArrayList<Integer>();
        test7a.add(-1);test7a.add(2);test7a.add(0);test7a.add(9);

        ArrayList<Integer> test7b = new ArrayList<Integer>();
        test7b.add(-4);test7b.add(0);test7b.add(3);test7b.add(9);

        System.out.println("Question 7 Tests:");
        System.out.print(test7a + " " + test7b + " --> ");
        filter(test7a, test7b);
        System.out.println(test7a + " " + test7b);

        System.out.println("");

        ArrayList<String> test8a = new ArrayList<String>();
        test8a.add("A");test8a.add("A");test8a.add("B");test8a.add("C");test8a.add("C");
        
        System.out.println("Question 8 Tests:");
        System.out.print(test8a + " --> ");
        removeConsequtiveDuplicates(test8a);
        System.out.println(test8a);
        
    }   
}
